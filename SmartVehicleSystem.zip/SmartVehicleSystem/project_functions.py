# File name: project_functions
# Project: Final Capstone Project
# Program: Embedded Systems DEvelopement
# College: Conestoga College Cammridge Campus
# Term: Fall 2021
# Date: December 8th, 2021
# Students: Tayeb, Rohan, Bargav
# Professor: Ralph Stacey

"""
    The program contains all the functions used by Final_Integrated_software
    
"""

from rpi_hardware_pwm import HardwarePWM
import time
import RPi.GPIO as GPIO
import time


#Supress warnings
GPIO.setwarnings(False)

# Use "GPIO" pin numbering
GPIO.setmode(GPIO.BCM)

#Pin Assignment

# Motors
# right motor
GPIO_pin2 = 13
GPIO_pin7 = 6

#left motor
GPIO_pin10 = 23
GPIO_pin15 = 24

pwm_left = HardwarePWM(0, hz=60)# pwm at pin 18
pwm_right = HardwarePWM(1, hz=60)# pwm at pin 19
pwm_right.start(100)
pwm_left.start(100)

#Encoders
right_Encd_A = 20
right_Encd_B = 21

left_Encd_A = 25 
left_Encd_B = 8

# Ultrasound range finder
#Front
GPIO_TRIGGER_Front = 2
GPIO_ECHO_Front = 3
 
#Left
GPIO_TRIGGER_Left = 27
GPIO_ECHO_Left = 22

#Leds
yellow_led = 4
green_led = 17 # straight
left_red_led = 10
right_red_led = 9



# Global variables
right_motion_data = [] # each element is a tuple: (time.time(), counter)
left_motion_data = [] # each element is a tuple: (time.time(), counter)

 
right_counter = 0
left_counter = 0


start_car = True

front_free = True
left_free = True

#init_led_GPIOs()
def init_leds():
    GPIO.setup(yellow_led, GPIO.OUT)
    #GPIO.setup(yellow_led, GPIO.IN)
    GPIO.setup(green_led, GPIO.OUT)
    GPIO.setup(left_red_led, GPIO.OUT)
    GPIO.setup(right_red_led, GPIO.OUT)

#Init functions
def init_motors():
    
    # right motor
    GPIO.setup(GPIO_pin2, GPIO.OUT)
    GPIO.setup(GPIO_pin7, GPIO.OUT)

    # Left motor
    GPIO.setup(GPIO_pin10, GPIO.OUT)
    GPIO.setup(GPIO_pin15, GPIO.OUT)

    return

def init_encoders():
    
    GPIO.setup(right_Encd_A, GPIO.IN)
    GPIO.setup(right_Encd_B, GPIO.IN)
    GPIO.add_event_detect(right_Encd_A, GPIO.RISING, callback=right_revolutions, bouncetime=10)
    
    GPIO.setup(left_Encd_A, GPIO.IN)
    GPIO.setup(left_Encd_B, GPIO.IN)
    GPIO.add_event_detect(left_Encd_A, GPIO.RISING, callback=left_revolutions, bouncetime=10)

    return   
# Deetction
def init_detection():
    
    #set GPIO direction (IN / OUT)
    GPIO.setup(GPIO_TRIGGER_Front, GPIO.OUT)
    GPIO.setup(GPIO_ECHO_Front, GPIO.IN)
    
    GPIO.setup(GPIO_TRIGGER_Left, GPIO.OUT)
    GPIO.setup(GPIO_ECHO_Left, GPIO.IN)
    return


 
# Functions
#Motors
def run_Right_MTR(speed, direction): # pins 2 and 7

    if direction == 'FWD':
        
        GPIO.output(GPIO_pin2, GPIO.HIGH)
        GPIO.output(GPIO_pin7, GPIO.LOW)
        pwm_right.change_duty_cycle(speed) # speed is as duty cycle
    elif direction == 'BWD':
        GPIO.output(GPIO_pin2, GPIO.LOW)
        GPIO.output(GPIO_pin7, GPIO.HIGH)
        pwm_right.change_duty_cycle(speed) # speed is as duty cycle
    else: # stop
        GPIO.output(GPIO_pin2, GPIO.LOW)
        GPIO.output(GPIO_pin7, GPIO.LOW)
        pwm_right.change_duty_cycle(0)

def run_Left_MTR(speed, direction): # pins 10 and 15

    if direction == 'FWD':
        
        GPIO.output(GPIO_pin10, GPIO.HIGH)
        GPIO.output(GPIO_pin15, GPIO.LOW)
        pwm_left.change_duty_cycle(speed) # speed is as duty cycle
    elif direction == 'BWD':
        GPIO.output(GPIO_pin10, GPIO.LOW)
        GPIO.output(GPIO_pin15, GPIO.HIGH)
        pwm_left.change_duty_cycle(speed) # speed is as duty cycle
    else: # stop
        GPIO.output(GPIO_pin10, GPIO.LOW)
        GPIO.output(GPIO_pin15, GPIO.LOW)
        pwm_left.change_duty_cycle(0)

def stop_motors():
    run_Right_MTR(0, 'stop')
    run_Left_MTR(0, 'stop')

# Encoders
def right_revolutions(right_Encd_A):
    global right_counter
    global right_motion_data
    
    Switch_A = GPIO.input(right_Encd_A)
    
    Switch_B = GPIO.input(right_Encd_B)
   
 
    if (Switch_A == 1) and (Switch_B == 1):
        right_counter += 1
        right_motion_data.append((int (time.time()*1000), right_counter)) # in milliseconds
        while Switch_A == 1:
            Switch_A = GPIO.input(right_Encd_A)
        
        return
    else:
        return
    
def left_revolutions(left_Encd_A):
    global left_counter
    global left_motion_data
    
    Switch_A = GPIO.input(left_Encd_A)
   
    Switch_B = GPIO.input(left_Encd_B)
    

    if (Switch_A == 1) and (Switch_B == 1):
        left_counter += 1
        left_motion_data.append((int (time.time()*1000), left_counter)) # in milliseconds
        while Switch_A == 1:
            Switch_A = GPIO.input(left_Encd_A)
       
        return
    else:
        return

def get_counts_speed(speed_data):
    global right_motion_data
    global left_motion_data
    #start_time = int(time.time()*1000)
    try:
        
        while True:
            
            right_revolutions(right_Encd_A)
            left_revolutions(left_Encd_A)
            
            if(len(right_motion_data) >= 2) and (len(left_motion_data) >= 2):
                if ( (right_motion_data[-1][0] - right_motion_data[-2][0]) != 0 ) and ((left_motion_data[-1][0] - left_motion_data[-2][0]) != 0):
                    right_inst_count_speed = (right_motion_data[-1][1] - right_motion_data[-2][1] ) / (right_motion_data[-1][0] - right_motion_data[-2][0])
               
                
                    left_inst_count_speed = (left_motion_data[-1][1] - left_motion_data[-2][1] ) / (left_motion_data[-1][0] - left_motion_data[-2][0])
                
                # add speed data
                    t = (right_motion_data[-1][0]  +  left_motion_data[-1][0] )/ 2
                    speed_data.append((t,right_inst_count_speed , left_inst_count_speed ))
                
                time.sleep(0.0015)# 1/ 0.0015= 666.67
                return speed_data
        
    except KeyboardInterrupt:
        print("Done")
        GPIO.cleanup()



#Detection
def distance_detect(GPIO_TRIGGER, GPIO_ECHO):
    # set Trigger to HIGH
    GPIO.output(GPIO_TRIGGER, True)
    # set Trigger after 0.01ms to LOW
    time.sleep(0.00001)
    GPIO.output(GPIO_TRIGGER, False)

    StartTime = time.time()
    StopTime = time.time()

    # save StartTime
    while GPIO.input(GPIO_ECHO) == 0:
        StartTime = time.time()

    # save time of arrival
    while GPIO.input(GPIO_ECHO) == 1:
        StopTime = time.time()

    # time difference between start and arrival
    TimeElapsed = StopTime - StartTime
    # multiply with the sonic speed (34300 cm/s)
    # and divide by 2, because there and back
    distance = (TimeElapsed * 34300) / 2
    return distance

def detect_obstacle(GPIO_TRIGGER, GPIO_ECHO, free_distance): 
    
    if distance_detect(GPIO_TRIGGER, GPIO_ECHO) < free_distance:
        return True   
    else:
        return False

def reds_on():
    GPIO.output(left_red_led, GPIO.HIGH)
    time.sleep(0.002)
    GPIO.output(right_red_led, GPIO.HIGH)
    time.sleep(0.002)
    
def reds_off():
    GPIO.output(left_red_led, GPIO.LOW)
    time.sleep(0.002)
    GPIO.output(right_red_led, GPIO.LOW)
    time.sleep(0.002)
    
def left_red_on():
    GPIO.output(left_red_led, GPIO.HIGH)
    time.sleep(0.002)
   
def left_red_off():
    GPIO.output(left_red_led, GPIO.LOW)
    time.sleep(0.002)
    
def right_red_on():
    GPIO.output(left_red_led, GPIO.HIGH)
    time.sleep(0.002)
   
def right_red_off():
    GPIO.output(left_red_led, GPIO.LOW)
    time.sleep(0.002)   
    
def yellow_on():
    GPIO.output(yellow_led, GPIO.HIGH)
    time.sleep(0.002)
    
    
def yellow_off():
    GPIO.output(yellow_led, GPIO.LOW)
    time.sleep(0.002)
    
def green_on():
    GPIO.output(yellow_led, GPIO.HIGH)
    time.sleep(0.002)
    
    
def green_off():
    GPIO.output(yellow_led, GPIO.LOW)
    time.sleep(0.002)    
    
    
def light_on_led(led_name):
    if (led_name ==   yellow_led):
        GPIO.output(yellow_led, GPIO.HIGH)
        time.sleep(0.002)
    elif (led_name == green_led):
        GPIO.output(green_led, GPIO.HIGH)
        time.sleep(0.002)
    elif (led_name == left_red_led):
        GPIO.output(left_red_led, GPIO.HIGH)
        time.sleep(0.002)
    elif(led_name == right_red_led):
        GPIO.output(right_red_led, GPIO.HIGH)
        time.sleep(0.002)    
    
# motion functions
    
def go_forward_NoPID(duty):
    run_Right_MTR(duty, 'FWD')
    run_Left_MTR(duty, 'FWD')
    
def run_straight_NoPID(duty):
    param = 0.1
    run_Right_MTR(duty, 'FWD')
    run_Left_MTR(duty, 'FWD')
    time.sleep(0.1)
    
def accelerate_to_speed(accel, duty):
    global start_car
    current_duty = 15
    start_time = time.time()

    if (start_car == True):
        while ((abs(current_duty - duty)) > 1 ):

            elapsed_time = time.time() - start_time
            current_duty = accel * elapsed_time
            run_Right_MTR(current_duty, 'FWD')
            run_Left_MTR(current_duty, 'FWD')
            time.sleep(0.02)
    start_car = False
    return int(current_duty)
  

def stop_car(decel, duty):
 
    start_time = time.time()
    
    current_duty = duty
    while ((abs(current_duty)) > 15 ):

        elapsed_time = time.time() - start_time
        current_duty = duty - decel * elapsed_time
        run_Right_MTR(current_duty, 'FWD')
        run_Left_MTR(current_duty, 'FWD')
        time.sleep(0.02)
    stop_motors()    
    print("car stopped")
    if current_duty < 2:
        return True
    else:
        return False
   
   

def go_backward_NoPID(duty):
    run_Right_MTR(duty, 'BWD')
    run_Left_MTR(duty, 'BWD')
    
    
def test_turn_right(radius_fact, duty):
    
    turn_count = 0
    if duty > 25:
        duty = 25
    
    run_Right_MTR(radius_fact * duty, 'FWD')
    run_Left_MTR(duty, 'FWD')   

    return turn_count


def test_turn_left(radius_fact, duty):
    
    turn_count = 0
    if duty > 25:
        duty = 25
    
    run_Right_MTR(duty, 'FWD')
    run_Left_MTR(radius_fact * duty, 'FWD')   

    return turn_count
    
def turn_right_1(radius_fact, duty, distance_to_avoid):
    front_free = False
   
    if duty > 20:
        duty = 20
    while not front_free:
       
        run_Left_MTR(radius_fact * duty, 'FWD')
        run_Right_MTR(duty, 'FWD')
       
        front_free = not detect_obstacle(GPIO_TRIGGER_Front, GPIO_ECHO_Front, distance_to_avoid)
        time.sleep(0.3)

    return True

def turn_right_2( front_free,radius_fact, duty):
    front_free = False
    turn_count = 200
    if duty > 20:
        duty = 20
    while not front_free:

        run_Left_MTR(radius_fact * duty, 'FWD')
        run_Right_MTR(duty, 'FWD')
       
        time.sleep(0.3)
    return True

def turn_left_free(turn_count,radius_fact, duty):
    if duty > 30:
        duty = 30
        count =0 
    while count < turn_count:
        run_Left_MTR( duty, 'FWD')
        run_Right_MTR(radius_fact *duty, 'FWD')
        count = count + 5
    go_forward_NoPID(duty)
    return True

def turn_left_free_2(turn_time,max_time,radius_fact, duty):
    if duty > 25:
        duty = 25
    if turn_time > max_time:
        return False
    
    run_Left_MTR( duty, 'FWD')
    run_Right_MTR(radius_fact *duty, 'FWD')
   
    return True
    
def turn_left(turn_count,radius_fact, duty):
    global front_free
    global left_free
    turn_count = 0
    if duty > 30:
        duty = 30
    while not front_free:
        run_Right_MTR(radius_fact * duty, 'FWD')
        run_Left_MTR(duty, 'FWD')
    while not left_free:
        go_forward_NoPID(duty)
    turn_left(turn_count,radius_fact, duty)

